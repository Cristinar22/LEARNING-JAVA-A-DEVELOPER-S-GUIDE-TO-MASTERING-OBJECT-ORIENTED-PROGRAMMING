public class Main {
    public static void main(String[] args) {
        // Create a new Book object
        Book myBook = new Book("Java Programming", "John Doe", 300);
        
        // Call the displayBookInfo method
        myBook.displayBookInfo();
    }
}