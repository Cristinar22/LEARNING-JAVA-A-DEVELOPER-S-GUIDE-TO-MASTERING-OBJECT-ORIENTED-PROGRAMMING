public class Main {
    public static void main(String[] args) {
        // Creating a new Car object
        Car myCar = new Car();
        myCar.make = "Toyota";
        myCar.model = "Corolla";
        myCar.year = 2020;
        
        // Calling the startEngine method
        myCar.startEngine();
    }
}