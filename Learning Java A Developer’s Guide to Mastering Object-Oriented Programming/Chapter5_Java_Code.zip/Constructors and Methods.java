public class Car {
    String make;
    String model;
    int year;
    
    // Parameterized constructor
    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }
    
    // Method
    public void startEngine() {
        System.out.println("The engine is now running.");
    }
}