public class Book {
    String title;
    String author;
    int pages;
    
    // Constructor to initialize a Book object
    public Book(String title, String author, int pages) {
        this.title = title;
        this.author = author;
        this.pages = pages;
    }
    
    // Method to display the book's information
    public void displayBookInfo() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Pages: " + pages);
    }
    
    // Method to check if the book is a long read
    public boolean isLongRead() {
        return pages > 300;
    }
}