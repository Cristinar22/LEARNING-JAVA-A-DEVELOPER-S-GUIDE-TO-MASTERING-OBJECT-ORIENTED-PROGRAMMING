public class Car {
    // Fields (attributes)
    String make;
    String model;
    int year;
    
    // Method (action)
    public void startEngine() {
        System.out.println("The engine is now running.");
    }
}