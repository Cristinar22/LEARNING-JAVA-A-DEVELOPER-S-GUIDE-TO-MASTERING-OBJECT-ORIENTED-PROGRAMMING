public class Car {
    String make;
    String model;
    int year;
    
    // Default constructor
    public Car() {
        make = "Unknown";
        model = "Unknown";
        year = 0;
    }
    
    public void startEngine() {
        System.out.println("The engine is now running.");
    }
}