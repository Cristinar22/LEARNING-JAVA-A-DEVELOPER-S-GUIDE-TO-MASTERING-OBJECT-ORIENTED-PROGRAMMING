public class Main {
    public static void main(String[] args) {
        // Create a new Book object
        Book myBook = new Book("Java Programming", "John Doe", 350);
        
        // Display the book's information
        myBook.displayBookInfo();
        
        // Check if the book is a long read
        if (myBook.isLongRead()) {
            System.out.println("This is a long read.");
        } else {
            System.out.println("This is a short read.");
        }
    }
}