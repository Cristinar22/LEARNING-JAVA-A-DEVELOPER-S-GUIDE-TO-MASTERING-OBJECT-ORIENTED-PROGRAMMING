public class Main {
    public static void main(String[] args) {
        // Creating a new Car object with the parameterized constructor
        Car myCar = new Car("Toyota", "Corolla", 2020);
        myCar.startEngine();
    }
}