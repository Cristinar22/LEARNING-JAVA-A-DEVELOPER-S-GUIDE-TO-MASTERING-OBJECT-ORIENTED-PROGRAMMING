public class Car {
    String make;
    String model;
    int year;
    
    // Constructor using this keyword
    public Car(String make, String model, int year) {
        this.make = make;      // this.make refers to the instance variable
        this.model = model;    // this.model refers to the instance variable
        this.year = year;      // this.year refers to the instance variable
    }
}