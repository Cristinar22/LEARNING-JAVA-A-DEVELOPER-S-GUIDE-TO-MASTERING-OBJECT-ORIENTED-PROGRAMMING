
import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        Queue<String> queue = new LinkedList<>();

        // Adding elements to the Queue
        queue.add("Task 1");
        queue.add("Task 2");
        queue.add("Task 3");

        // Display the Queue
        System.out.println("Queue: " + queue);

        // Removing an element (FIFO)
        String task = queue.remove();
        System.out.println("Removed: " + task);
        
        // Display the Queue after removal
        System.out.println("Queue after removal: " + queue);
        
        // Peeking at the front element
        System.out.println("Next task: " + queue.peek());
    }
}
