
import java.util.HashSet;
import java.util.Set;

public class SetExample {
    public static void main(String[] args) {
        Set<String> colors = new HashSet<>();

        // Adding elements to the Set
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Red");  // Duplicates not allowed

        // Display the Set
        System.out.println("Colors: " + colors);

        // Checking if the Set contains an element
        boolean hasGreen = colors.contains("Green");
        System.out.println("Contains Green: " + hasGreen);
    }
}
