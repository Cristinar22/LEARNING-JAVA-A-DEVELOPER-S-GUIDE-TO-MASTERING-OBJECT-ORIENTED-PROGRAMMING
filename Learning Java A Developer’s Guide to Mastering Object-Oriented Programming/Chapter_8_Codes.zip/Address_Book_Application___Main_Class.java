
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AddressBook addressBook = new AddressBook();

        // Adding some contacts
        addressBook.addContact(new Contact("John Doe", "123-456-7890", "john@example.com"));
        addressBook.addContact(new Contact("Jane Smith", "987-654-3210", "jane@example.com"));

        // Display all contacts
        System.out.println("All Contacts:");
        addressBook.displayContacts();

        // Searching for a contact
        System.out.print("
Enter name to search: ");
        String name = scanner.nextLine();
        Contact contact = addressBook.searchContact(name);
        if (contact != null) {
            System.out.println("Found: " + contact);
        } else {
            System.out.println("Contact not found.");
        }

        // Removing a contact
        System.out.print("
Enter name to remove: ");
        name = scanner.nextLine();
        addressBook.removeContact(name);
        System.out.println("Updated Contacts:");
        addressBook.displayContacts();
    }
}
