
import java.util.ArrayList;
import java.util.List;

public class ListExample {
    public static void main(String[] args) {
        List<String> fruits = new ArrayList<>();

        // Adding elements to the List
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Orange");
        fruits.add("Apple");  // Duplicates allowed

        // Display the List
        System.out.println("Fruits: " + fruits);

        // Accessing an element by index
        System.out.println("First fruit: " + fruits.get(0));

        // Removing an element
        fruits.remove("Banana");
        System.out.println("Fruits after removal: " + fruits);

        // Checking if the List contains an element
        boolean hasApple = fruits.contains("Apple");
        System.out.println("Contains Apple: " + hasApple);
    }
}
