
import java.util.HashMap;
import java.util.Map;

public class MapExample {
    public static void main(String[] args) {
        Map<String, Integer> studentScores = new HashMap<>();

        // Adding key-value pairs to the Map
        studentScores.put("Alice", 85);
        studentScores.put("Bob", 92);
        studentScores.put("Charlie", 78);
        studentScores.put("Alice", 90);  // Overwrites previous value for Alice

        // Display the Map
        System.out.println("Student Scores: " + studentScores);

        // Accessing a value by key
        System.out.println("Bob's score: " + studentScores.get("Bob"));

        // Checking if a key exists
        boolean hasAlice = studentScores.containsKey("Alice");
        System.out.println("Contains Alice: " + hasAlice);
    }
}
