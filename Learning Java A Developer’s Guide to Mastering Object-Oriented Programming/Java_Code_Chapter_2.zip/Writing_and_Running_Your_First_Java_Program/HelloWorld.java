public class HelloWorld {
    public static void main(String[] args) {
        // This is where your code goes
        System.out.println("Hello, World!");  // Prints Hello, World! to the console
    }
}
