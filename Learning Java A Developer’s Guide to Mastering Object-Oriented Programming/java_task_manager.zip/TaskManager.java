import java.util.ArrayList;
import java.util.List;

public class TaskManager {
    private List<Task> taskList;

    public TaskManager() {
        taskList = new ArrayList<>();
    }

    public void addTask(String name, String description, String dueDate) {
        Task newTask = new Task(name, description, dueDate);
        taskList.add(newTask);
    }

    public void removeTask(String name) {
        taskList.removeIf(task -> task.getName().equalsIgnoreCase(name));
    }

    public void displayTasks() {
        if (taskList.isEmpty()) {
            System.out.println("No tasks to display.");
        } else {
            taskList.forEach(System.out::println);
        }
    }
}