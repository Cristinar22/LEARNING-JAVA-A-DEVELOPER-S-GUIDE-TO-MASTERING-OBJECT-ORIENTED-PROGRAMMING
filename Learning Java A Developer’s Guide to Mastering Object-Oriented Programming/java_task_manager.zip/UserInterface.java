import java.util.Scanner;

public class UserInterface {
    private TaskManager taskManager;
    private Scanner scanner;

    public UserInterface() {
        taskManager = new TaskManager();
        scanner = new Scanner(System.in);
    }

    public void showMenu() {
        while (true) {
            System.out.println("\nTask Manager Menu:");
            System.out.println("1. Add Task");
            System.out.println("2. Remove Task");
            System.out.println("3. Display Tasks");
            System.out.println("4. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline left-over

            switch (choice) {
                case 1:
                    addTask();
                    break;
                case 2:
                    removeTask();
                    break;
                case 3:
                    taskManager.displayTasks();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private void addTask() {
        System.out.print("Enter task name: ");
        String name = scanner.nextLine();
        System.out.print("Enter task description: ");
        String description = scanner.nextLine();
        System.out.print("Enter task due date: ");
        String dueDate = scanner.nextLine();

        taskManager.addTask(name, description, dueDate);
        System.out.println("Task added successfully.");
    }

    private void removeTask() {
        System.out.print("Enter task name to remove: ");
        String name = scanner.nextLine();
        taskManager.removeTask(name);
        System.out.println("Task removed successfully.");
    }

    public static void main(String[] args) {
        UserInterface ui = new UserInterface();
        ui.showMenu();
    }
}