public class Person {
    // Private field (cannot be accessed directly from outside)
    private int age;

    // Constructor to initialize the age
    public Person(int age) {
        this.age = age;
    }

    // Public getter method to access the age
    public int getAge() {
        return age;
    }

    // Public setter method to modify the age
    public void setAge(int age) {
        if (age > 0) {
            this.age = age;
        } else {
            System.out.println("Age must be positive.");
        }
    }
}