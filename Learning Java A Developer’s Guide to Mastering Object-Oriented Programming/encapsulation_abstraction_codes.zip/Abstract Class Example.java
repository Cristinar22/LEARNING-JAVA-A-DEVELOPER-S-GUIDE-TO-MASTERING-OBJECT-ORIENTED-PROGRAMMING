// Abstract class
public abstract class Shape {
    // Abstract method (no implementation)
    public abstract void draw();

    // Regular method
    public void display() {
        System.out.println("Displaying a shape.");
    }
}

// Subclass Circle
public class Circle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a circle.");
    }
}

// Subclass Rectangle
public class Rectangle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a rectangle.");
    }
}