// Interface
public interface Drawable {
    void draw();  // No implementation
}

// Class Circle implements Drawable
public class Circle implements Drawable {
    @Override
    public void draw() {
        System.out.println("Drawing a circle.");
    }
}

// Class Rectangle implements Drawable
public class Rectangle implements Drawable {
    @Override
    public void draw() {
        System.out.println("Drawing a rectangle.");
    }
}