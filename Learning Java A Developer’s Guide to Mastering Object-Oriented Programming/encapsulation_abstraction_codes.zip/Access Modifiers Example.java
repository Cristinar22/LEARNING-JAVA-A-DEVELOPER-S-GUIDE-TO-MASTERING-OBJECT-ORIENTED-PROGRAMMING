public class AccessModifiersExample {
    public int publicField;      // Can be accessed anywhere
    private int privateField;    // Can only be accessed within this class
    protected int protectedField; // Can be accessed within the same package or subclasses

    public void setPrivateField(int value) {
        if (value > 0) {
            privateField = value;
        } else {
            System.out.println("Invalid value.");
        }
    }

    public int getPrivateField() {
        return privateField;
    }
}