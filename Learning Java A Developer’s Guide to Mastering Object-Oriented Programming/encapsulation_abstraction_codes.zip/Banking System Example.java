// BankAccount Class
public class BankAccount {
    private double balance;

    // Constructor to initialize balance
    public BankAccount(double initialBalance) {
        if (initialBalance > 0) {
            balance = initialBalance;
        }
    }

    // Deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Amount must be positive.");
        }
    }

    // Withdraw money
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: " + amount);
        } else {
            System.out.println("Invalid withdrawal amount.");
        }
    }

    // Get balance
    public double getBalance() {
        return balance;
    }
}

// Loan Interface
public interface Loan {
    void applyForLoan(double amount);
}

// Customer Class implementing Loan Interface
public class Customer implements Loan {
    private String name;
    private BankAccount account;

    public Customer(String name, double initialBalance) {
        this.name = name;
        this.account = new BankAccount(initialBalance);
    }

    @Override
    public void applyForLoan(double amount) {
        System.out.println(name + " applied for a loan of " + amount);
    }

    public void depositMoney(double amount) {
        account.deposit(amount);
    }

    public void withdrawMoney(double amount) {
        account.withdraw(amount);
    }

    public double checkBalance() {
        return account.getBalance();
    }
}

// Main Program
public class Main {
    public static void main(String[] args) {
        Customer customer1 = new Customer("John Doe", 1000);
        customer1.depositMoney(500);
        customer1.withdrawMoney(200);
        System.out.println("Current Balance: " + customer1.checkBalance());

        customer1.applyForLoan(5000);
    }
}