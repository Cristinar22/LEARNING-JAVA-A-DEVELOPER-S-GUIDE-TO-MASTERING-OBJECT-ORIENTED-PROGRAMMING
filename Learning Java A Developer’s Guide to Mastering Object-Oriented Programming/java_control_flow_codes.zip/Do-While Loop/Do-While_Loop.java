public class DoWhileLoopExample {
    public static void main(String[] args) {
        int i = 1;
        do {
            System.out.println(i);
            i++; // incrementing the counter
        } while (i <= 10);
    }
}