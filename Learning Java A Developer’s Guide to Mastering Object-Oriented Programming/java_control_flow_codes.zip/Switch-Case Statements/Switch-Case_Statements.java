import java.util.Scanner;

public class WeekdayMessage {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a day number (1-7): ");
        int day = scanner.nextInt();

        switch (day) {
            case 1:
                System.out.println("Today is Monday. Start the week strong!");
                break;
            case 2:
                System.out.println("Today is Tuesday. Keep going!");
                break;
            case 3:
                System.out.println("Today is Wednesday. You're halfway there!");
                break;
            case 4:
                System.out.println("Today is Thursday. Almost there!");
                break;
            case 5:
                System.out.println("Today is Friday. It's the weekend eve!");
                break;
            case 6:
                System.out.println("Today is Saturday. Time to relax!");
                break;
            case 7:
                System.out.println("Today is Sunday. Prepare for the week ahead.");
                break;
            default:
                System.out.println("Invalid day number. Please enter a number between 1 and 7.");
        }
    }
}