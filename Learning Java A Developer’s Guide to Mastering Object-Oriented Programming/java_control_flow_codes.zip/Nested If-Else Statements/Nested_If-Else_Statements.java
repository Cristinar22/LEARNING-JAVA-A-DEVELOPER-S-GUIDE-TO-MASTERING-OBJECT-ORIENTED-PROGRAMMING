int age = 25;

if (age >= 18) {
    if (age <= 65) {
        System.out.println("You are an adult.");
    } else {
        System.out.println("You are a senior citizen.");
    }
} else {
    System.out.println("You are a minor.");
}