
import java.util.ArrayList;
import java.util.List;

// Subject
class ChatRoom {
    private List<User> users = new ArrayList<>();

    public void addUser(User user) {
        users.add(user);
    }

    public void removeUser(User user) {
        users.remove(user);
    }

    public void sendMessage(String message, User sender) {
        for (User user : users) {
            if (user != sender) {
                user.receiveMessage(message);
            }
        }
    }
}

// Observer
class User {
    private String name;

    public User(String name) {
        this.name = name;
    }

    public void sendMessage(ChatRoom chatRoom, String message) {
        chatRoom.sendMessage(message, this);
    }

    public void receiveMessage(String message) {
        System.out.println(name + " received: " + message);
    }
}

public class ObserverPatternExample {
    public static void main(String[] args) {
        ChatRoom chatRoom = new ChatRoom();
        
        User alice = new User("Alice");
        User bob = new User("Bob");
        User charlie = new User("Charlie");
        
        chatRoom.addUser(alice);
        chatRoom.addUser(bob);
        chatRoom.addUser(charlie);

        alice.sendMessage(chatRoom, "Hello, everyone!");
        bob.sendMessage(chatRoom, "Hi Alice!");
    }
}
