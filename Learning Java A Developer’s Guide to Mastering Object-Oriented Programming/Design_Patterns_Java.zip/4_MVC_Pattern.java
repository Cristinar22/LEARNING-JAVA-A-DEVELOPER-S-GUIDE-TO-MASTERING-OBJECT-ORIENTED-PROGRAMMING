
// Model
class User {
    private String name;

    public User(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

// View
class UserView {
    public void displayUserInfo(String userName) {
        System.out.println("User name: " + userName);
    }
}

// Controller
class UserController {
    private User model;
    private UserView view;

    public UserController(User model, UserView view) {
        this.model = model;
        this.view = view;
    }

    public void updateUserName(String name) {
        model = new User(name);
    }

    public void displayUserInfo() {
        view.displayUserInfo(model.getName());
    }
}

public class MVCPatternExample {
    public static void main(String[] args) {
        User user = new User("John");
        UserView userView = new UserView();
        UserController userController = new UserController(user, userView);

        userController.displayUserInfo();
        userController.updateUserName("Alice");
        userController.displayUserInfo();
    }
}
