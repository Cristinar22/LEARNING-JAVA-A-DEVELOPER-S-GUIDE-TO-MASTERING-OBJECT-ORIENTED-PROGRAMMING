import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorServiceExample {
    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(3);  // Create a pool of 3 threads

        executorService.submit(() -> {
            System.out.println("Task 1 is running");
        });

        executorService.submit(() -> {
            System.out.println("Task 2 is running");
        });

        executorService.submit(() -> {
            System.out.println("Task 3 is running");
        });

        executorService.shutdown();  // Shut down the executor service
    }
}
