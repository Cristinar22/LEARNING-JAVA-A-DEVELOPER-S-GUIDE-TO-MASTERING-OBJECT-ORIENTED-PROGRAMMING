
public class ElectricCar extends Car {
    // New attribute for ElectricCar
    int batteryLife;
    
    // Constructor
    public ElectricCar(String make, String model, int year, int batteryLife) {
        super(make, model, year);  // Calling the constructor of the parent class
        this.batteryLife = batteryLife;
    }
    
    // New method for ElectricCar
    public void displayBatteryInfo() {
        System.out.println("Battery Life: " + batteryLife + " hours");
    }
    
    public static void main(String[] args) {
        // Creating an object of the ElectricCar class
        ElectricCar eCar = new ElectricCar("Tesla", "Model S", 2022, 24);
        eCar.displayCarInfo();  // Inherited from Car class
        eCar.displayBatteryInfo();  // Specific to ElectricCar
    }
}
