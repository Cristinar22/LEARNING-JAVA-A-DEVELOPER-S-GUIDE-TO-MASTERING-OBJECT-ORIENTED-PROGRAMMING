
public class Main {
    public static void main(String[] args) {
        Car myCar = new ElectricCar("Tesla", "Model S", 2022, 24);
        myCar.displayCarInfo();  // The method in the ElectricCar class is called due to polymorphism
    }
}
