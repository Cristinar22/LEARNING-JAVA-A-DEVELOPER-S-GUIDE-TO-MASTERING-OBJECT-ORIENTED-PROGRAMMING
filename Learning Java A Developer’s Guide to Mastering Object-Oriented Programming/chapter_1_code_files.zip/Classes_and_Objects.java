
public class Car {
    // Attributes (fields)
    String make;
    String model;
    int year;
    
    // Constructor
    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }
    
    // Method
    public void displayCarInfo() {
        System.out.println("Car Info: " + year + " " + make + " " + model);
    }
    
    public static void main(String[] args) {
        // Creating an object of the Car class
        Car car1 = new Car("Toyota", "Corolla", 2020);
        car1.displayCarInfo();
    }
}
