
public abstract class Vehicle {
    // Abstract method
    public abstract void startEngine();
}

public class Car extends Vehicle {
    public void startEngine() {
        System.out.println("The car engine is now running.");
    }
}
