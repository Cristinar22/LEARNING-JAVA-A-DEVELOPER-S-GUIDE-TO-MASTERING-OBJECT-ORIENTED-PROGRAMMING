public class UncheckedExceptionExample {
    public static void main(String[] args) {
        int result = 10 / 0;  // This will throw an ArithmeticException
        System.out.println("Result: " + result);
    }
}