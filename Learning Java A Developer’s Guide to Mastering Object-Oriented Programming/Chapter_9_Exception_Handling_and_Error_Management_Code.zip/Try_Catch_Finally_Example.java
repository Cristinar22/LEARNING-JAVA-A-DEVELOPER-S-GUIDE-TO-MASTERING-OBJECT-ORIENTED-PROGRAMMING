import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TryCatchFinallyExample {
    public static void main(String[] args) {
        Scanner scanner = null;
        try {
            // Try to open a file and read its contents
            File file = new File("myFile.txt");
            scanner = new Scanner(file);  // This could throw a FileNotFoundException
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            // Handle the exception if file is not found
            System.out.println("Error: The file was not found.");
        } finally {
            // Finally block ensures the scanner is closed whether or not an exception occurred
            if (scanner != null) {
                scanner.close();
                System.out.println("Scanner closed.");
            }
        }
    }
}