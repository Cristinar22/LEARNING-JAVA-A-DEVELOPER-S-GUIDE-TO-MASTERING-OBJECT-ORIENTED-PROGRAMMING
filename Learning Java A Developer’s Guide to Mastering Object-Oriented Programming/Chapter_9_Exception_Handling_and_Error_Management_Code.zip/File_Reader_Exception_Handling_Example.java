import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileReaderExample {
    public static void main(String[] args) {
        Scanner scanner = null;

        try {
            // Open a file to read
            File file = new File("sample.txt");
            scanner = new Scanner(file);

            // Read and print each line of the file
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }

        } catch (FileNotFoundException e) {
            // Handle the case where the file does not exist
            System.out.println("Error: The file was not found.");
        } finally {
            // Close the scanner in the finally block to release the resource
            if (scanner != null) {
                scanner.close();
                System.out.println("Scanner closed.");
            }
        }
    }
}