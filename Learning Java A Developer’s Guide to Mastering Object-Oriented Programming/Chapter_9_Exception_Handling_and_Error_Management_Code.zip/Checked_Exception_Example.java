import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CheckedExceptionExample {
    public static void main(String[] args) {
        try {
            // Attempting to read a file
            File file = new File("nonexistentFile.txt");
            Scanner scanner = new Scanner(file);  // This might throw a FileNotFoundException
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            // Handle the exception (e.g., print an error message)
            System.out.println("Error: The file was not found.");
        }
    }
}