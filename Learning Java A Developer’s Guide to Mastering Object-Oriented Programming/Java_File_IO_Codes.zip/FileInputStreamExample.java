import java.io.FileInputStream;
import java.io.IOException;

public class FileInputStreamExample {
    public static void main(String[] args) {
        // Create a FileInputStream object to open the file
        try (FileInputStream fis = new FileInputStream("example.txt")) {
            int byteData;
            // Read byte-by-byte until the end of the file
            while ((byteData = fis.read()) != -1) {
                System.out.print((char) byteData); // Convert byte to char
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }
}
