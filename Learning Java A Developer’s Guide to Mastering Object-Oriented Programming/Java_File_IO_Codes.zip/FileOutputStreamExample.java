import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamExample {
    public static void main(String[] args) {
        String data = "Hello, Java File I/O!";
        
        try (FileOutputStream fos = new FileOutputStream("output.txt")) {
            // Write the string data as bytes to the file
            fos.write(data.getBytes());  // Convert string to bytes and write to file
        } catch (IOException e) {
            System.out.println("Error writing to the file: " + e.getMessage());
        }
    }
}
