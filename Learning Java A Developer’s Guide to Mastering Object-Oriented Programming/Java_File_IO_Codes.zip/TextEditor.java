import java.io.*;
import java.util.Scanner;

public class TextEditor {
    private String content;

    public TextEditor() {
        content = "";
    }

    // Method to open a file and read its content
    public void openFile(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                content += line + "\n";
            }
        } catch (IOException e) {
            System.out.println("Error opening file: " + e.getMessage());
        }
    }

    // Method to save content to a file
    public void saveFile(String fileName) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            bw.write(content);
        } catch (IOException e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
    }

    // Method to edit the content
    public void editContent(String newText) {
        content = newText;
    }

    // Method to display the content
    public void displayContent() {
        System.out.println(content);
    }
}
