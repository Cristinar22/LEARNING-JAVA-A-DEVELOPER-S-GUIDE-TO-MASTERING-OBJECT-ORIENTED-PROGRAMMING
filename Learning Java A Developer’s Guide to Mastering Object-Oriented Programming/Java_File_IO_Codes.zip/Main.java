import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        TextEditor editor = new TextEditor();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Text Editor!");
        System.out.print("Enter file name to open: ");
        String fileName = scanner.nextLine();
        
        // Open the file and display its content
        editor.openFile(fileName);
        editor.displayContent();

        System.out.println("Enter new content for the file:");
        String newContent = scanner.nextLine();
        editor.editContent(newContent);

        System.out.print("Enter file name to save: ");
        String saveFileName = scanner.nextLine();
        
        // Save the new content to a file
        editor.saveFile(saveFileName);
        System.out.println("File saved successfully.");
    }
}
