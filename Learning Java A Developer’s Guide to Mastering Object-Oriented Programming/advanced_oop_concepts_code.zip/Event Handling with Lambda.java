import javax.swing.*;
import java.awt.event.ActionListener;

public class EventHandlingWithLambda {
    public static void main(String[] args) {
        // Create a JFrame (window)
        JFrame frame = new JFrame("Button Click Example");
        JButton button = new JButton("Click Me");

        // Using a lambda expression for event handling
        button.addActionListener(e -> System.out.println("Button was clicked!"));

        frame.add(button);
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}