public class Main {
    public static void main(String[] args) {
        // Creating an anonymous class that implements the Runnable interface
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                System.out.println("Running in an anonymous class.");
            }
        };

        // Running the thread
        Thread thread = new Thread(runnable);
        thread.start();
    }
}