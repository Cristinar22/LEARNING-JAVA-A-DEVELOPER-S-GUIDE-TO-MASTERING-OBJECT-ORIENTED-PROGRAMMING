public class OuterClass {
    private String outerField = "I am an outer class field.";

    // Member Inner Class
    class InnerClass {
        public void display() {
            System.out.println(outerField);  // Accessing outer class's private field
        }
    }

    public void createInnerClass() {
        InnerClass inner = new InnerClass();  // Creating an object of the inner class
        inner.display();
    }

    public static void main(String[] args) {
        OuterClass outer = new OuterClass();
        outer.createInnerClass();
    }
}