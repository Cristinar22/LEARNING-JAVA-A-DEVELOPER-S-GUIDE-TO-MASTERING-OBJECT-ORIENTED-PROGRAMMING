public class LambdaExample {
    public static void main(String[] args) {
        // Using a lambda expression to implement the Runnable interface
        Runnable runnable = () -> System.out.println("Running in a lambda expression.");

        // Running the thread
        Thread thread = new Thread(runnable);
        thread.start();
    }
}