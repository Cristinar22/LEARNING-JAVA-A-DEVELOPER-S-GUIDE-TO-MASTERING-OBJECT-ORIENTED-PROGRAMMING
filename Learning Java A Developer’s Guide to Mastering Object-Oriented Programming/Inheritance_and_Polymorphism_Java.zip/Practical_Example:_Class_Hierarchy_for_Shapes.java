
// Parent class Shape
public class Shape {
    public void draw() {
        System.out.println("Drawing a shape");
    }
}

// Child class Circle
public class Circle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a circle");
    }
}

// Child class Rectangle
public class Rectangle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a rectangle");
    }
}
