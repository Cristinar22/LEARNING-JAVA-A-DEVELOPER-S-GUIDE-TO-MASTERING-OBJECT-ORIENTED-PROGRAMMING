
// Parent class
public class Animal {
    String name;

    // Constructor
    public Animal(String name) {
        this.name = name;
    }

    // Method in the parent class
    public void makeSound() {
        System.out.println("The animal makes a sound.");
    }
}

// Child class
public class Dog extends Animal {

    // Constructor for the Dog class
    public Dog(String name) {
        super(name);  // Calling the parent class constructor
    }

    // Method in the child class
    @Override
    public void makeSound() {
        System.out.println(name + " barks.");
    }
}
