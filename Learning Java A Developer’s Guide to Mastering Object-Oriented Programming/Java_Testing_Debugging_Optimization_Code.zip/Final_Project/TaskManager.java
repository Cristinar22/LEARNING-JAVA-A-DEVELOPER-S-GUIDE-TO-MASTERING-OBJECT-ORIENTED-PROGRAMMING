import java.util.*;

public class TaskManager {
    private List<Task> taskList = new ArrayList<>();

    public void addTask(String name, String description, String dueDate) {
        Task newTask = new Task(name, description, dueDate);
        taskList.add(newTask);
    }

    public void removeTask(String name) {
        taskList.removeIf(task -> task.getName().equals(name));
    }

    public List<Task> getAllTasks() {
        return taskList;
    }
}