import org.junit.Test;
import static org.junit.Assert.*;

public class TaskManagerTest {
    @Test
    public void testAddTask() {
        TaskManager manager = new TaskManager();
        manager.addTask("Task 1", "Complete Java assignment", "2023-05-01");
        
        assertEquals(1, manager.getAllTasks().size());
    }

    @Test
    public void testRemoveTask() {
        TaskManager manager = new TaskManager();
        manager.addTask("Task 1", "Complete Java assignment", "2023-05-01");
        manager.removeTask("Task 1");
        
        assertTrue(manager.getAllTasks().isEmpty());
    }
}