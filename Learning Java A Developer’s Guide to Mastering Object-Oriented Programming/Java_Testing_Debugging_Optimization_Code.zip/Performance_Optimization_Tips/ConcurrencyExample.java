import java.util.concurrent.*;

public class ConcurrencyExample {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(4);

        for (int i = 0; i < 10; i++) {
            executor.submit(() -> {
                // Simulate a task
                System.out.println("Task executed by: " + Thread.currentThread().getName());
            });
        }

        executor.shutdown();
    }
}