public class BuggyCode {
    public int sum(int a, int b) {
        int result = a + b;
        return result; // Expected result is sum of a and b
    }

    public static void main(String[] args) {
        BuggyCode buggyCode = new BuggyCode();
        int sumResult = buggyCode.sum(10, 20);
        System.out.println("Sum is: " + sumResult); // Expected output: 30
    }
}